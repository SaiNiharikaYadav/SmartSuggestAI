document.getElementById('recommendation-form').addEventListener('submit', function (e) {
    e.preventDefault();

    const data = {
        category: document.getElementById('category').value,
        subcategory: document.getElementById('subcategory').value,
        brand: document.getElementById('brand').value,
        price_range: document.getElementById('price-range').value,
        rating: document.getElementById('rating').value,
        location: document.getElementById('location').value,
        season: document.getElementById('season').value,
    };

    fetch('/recommend', {
        method: 'POST',
        headers: {
            'Content-Type': 'application/json',
        },
        body: JSON.stringify(data)
    })
    .then(response => {
        if (!response.ok) throw new Error("Failed to fetch recommendations");
        return response.json();
    })
    .then(results => {
        const container = document.getElementById('recommendation-results');
        container.innerHTML = '';

        if (results.length === 0) {
            container.innerHTML = "<p>No matching products found.</p>";
            return;
        }

        let output = "<h3>Recommended Products:</h3><ul>";
        results.forEach(product => {
            output += <li>${product.Name} - ${product.Brand} - ₹${product.Price}</li>;
        });
        output += "</ul>";
        container.innerHTML = output;
    })
    .catch(error => {
        console.error('Error:', error);
        alert("Something went wrong while fetching recommendations.");
    });
});