from flask import Flask, request, jsonify, render_template
import pandas as pd
from flask_cors import CORS

app = Flask(__name__)
CORS(app)  # Allow cross-origin requests

# Load your dataset
DATA_PATH = 'C:/Users/Niharika/OneDrive/Desktop/SmartSuggestAI/data/product_recommendation_data.csv'
df = pd.read_csv(DATA_PATH)

@app.route('/')
def index():
    return render_template('index.html')  # if you're serving HTML from Flask

@app.route('/recommend', methods=['POST'])
def recommend():
    data = request.get_json()

    # Extract filters from the frontend request
    category = data.get('category')
    subcategory = data.get('subcategory')
    brand = data.get('brand')
    max_price = float(data.get('price_range', 70000))
    min_rating = float(data.get('rating', 1))
    season = data.get('season')
    location = data.get('location')

    # Apply filters to the DataFrame
    filtered_df = df[
        (df['Category'].str.lower() == category.lower()) &
        (df['Subcategory'].str.lower() == subcategory.lower()) &
        (df['Brand'].str.lower() == brand.lower()) &
        (df['Price'] <= max_price) &
        (df['Product_Rating'] >= min_rating) &
        (df['Season'].str.lower() == season.lower()) &
        (df['Geographical_Location'].str.lower() == location.lower())
    ]

    # Select top 10 recommended products based on highest Probability_of_Recommendation
    filtered_df = filtered_df.sort_values(by='Probability_of_Recommendation', ascending=False).head(10)

    # Format response
    results = filtered_df[[
        'Product_ID', 'Category', 'Subcategory', 'Brand', 'Price',
        'Product_Rating', 'Season', 'Geographical_Location'
    ]].rename(columns={
        'Product_ID': 'ID',
        'Product_Rating': 'Rating',
        'Geographical_Location': 'Location'
    })

    return jsonify(results.to_dict(orient='records'))

if __name__ == '__main__':
    app.run(debug=True)