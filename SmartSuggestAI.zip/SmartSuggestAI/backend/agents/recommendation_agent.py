import pandas as pd

class RecommendAgent:
    def __init__(self, product_data_path):
        self.product_data_path = product_data_path
        self.df = pd.read_csv(product_data_path)

    def get_recommendations(self, category=None, min_price=None, max_price=None):
        df = self.df.copy()

        if category:
            df = df[df['Category'].str.lower() == category.lower()]
        if min_price is not None:
            df = df[df['Price'] >= min_price]
        if max_price is not None:
            df = df[df['Price'] <= max_price]

        df = df.sort_values(by='Probability_of_Recommendation', ascending=False)
        recommendations = df[['Subcategory', 'Price']].head(5).rename(columns={"Subcategory": "name"})

        return recommendations.to_dict(orient="records")


if __name__ == '__main__':
    agent = RecommendAgent(r'C:\Users\Niharika\OneDrive\Desktop\SmartSuggestAI\data\product_recommendation_data.csv')
    result = agent.get_recommendations(category='Books', min_price=100, max_price=5000)
    print(result)
