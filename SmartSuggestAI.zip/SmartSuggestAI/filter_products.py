import requests
import json

# Define the API endpoint
url = 'http://127.0.0.1:5000/filter-products'

# Create a sample filter (modify as needed)
filters = {
    'brand': 'Brand A',   # Example filter for brand
    'season': 'Winter',   # Example filter for season
    'price': 1000,        # Example filter for price (less than or equal to 1000)
    'rating': 4           # Example filter for rating (greater than or equal to 4)
}

# Send a POST request to the Flask server
response = requests.post(url, json=filters)

# Print the response from the server (filtered data)
if response.status_code == 200:
    print("Filtered Products:", json.dumps(response.json(), indent=4))
else:
    print("Error:", response.status_code)
