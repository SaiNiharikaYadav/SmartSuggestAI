from flask import Flask, request, jsonify
import pandas as pd

app = Flask(__name__)

# Ensure you provide the correct path for your CSV file
df = pd.read_csv(r'C:\Users\Niharika\OneDrive\Desktop\SmartSuggestAI\data\product_recommendation_data.csv')  # Corrected path

@app.route('/filter-products', methods=['POST'])
def filter_products():
    try:
        # Get filters from the request (filters sent by the frontend)
        filters = request.get_json()

        # Apply filters to the DataFrame
        filtered_data = df

        # Apply each filter if provided
        if filters.get('brand'):
            filtered_data = filtered_data[filtered_data['Brand'] == filters['brand']]
        if filters.get('season'):
            filtered_data = filtered_data[filtered_data['Season'] == filters['season']]
        if filters.get('price'):
            filtered_data = filtered_data[filtered_data['Price'] <= filters['price']]
        if filters.get('rating'):
            filtered_data = filtered_data[filtered_data['Product_Rating'] >= filters['rating']]

        # Convert the filtered DataFrame to a dictionary and return it
        filtered_products = filtered_data.to_dict(orient='records')

        return jsonify(filtered_products)

    except Exception as e:
        return jsonify({'error': str(e)})

if __name__ == '__main__':
    app.run(debug=True)
