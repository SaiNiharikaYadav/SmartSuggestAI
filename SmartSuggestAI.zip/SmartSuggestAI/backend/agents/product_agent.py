def get_products():
    # Dummy list for now
    return [{"name": "Smartphone", "price": 1999}, {"name": "Laptop", "price": 2999}]
